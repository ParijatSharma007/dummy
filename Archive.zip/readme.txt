reg_api = "http://localhost:8000/users/signin";
login_api = "http://localhost:8000/users/login";
profile_api = "http://localhost:8000/users/profile-details";

use authorization instead of x-access-token

profilePic path is already set no need to create again
