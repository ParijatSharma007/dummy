const url = {
  baseUrl: "http://localhost:8000/",
};

module.exports = url